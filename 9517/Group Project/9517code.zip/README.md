# COMP9517 Group Project - Agricultural Pest Detection

## Project Overview
This project implements multiple computer vision methods for detecting and classifying agricultural pests using the AgroPest-12 dataset. We compare traditional machine learning approaches with state-of-the-art deep learning detectors to evaluate their performance in real-world agricultural environments.


## Dataset
**AgroPest-12**: Available from [Kaggle](https://www.kaggle.com/datasets/rupankarmajumdar/crop-pests-dataset)
- 11,502 training images
- 1,095 validation images
- 546 test images
- 12 insect pest classes


### 1. Data Preparation
Download the AgroPest-12 dataset and organize as follows:
```
data/
├── train/
├── valid/
└── test/
└── data.yaml/
```
## Evaluation Metrics
Our methods are evaluated using:
- **Detection**: Mean Average Precision (mAP)
- **Classification**: Precision, Recall, F1-Score, Accuracy, AUC
- **Efficiency**: Training time, Inference time



## Environment Setup

### Prerequisites
- Python 3.11+
- CUDA-capable GPU (recommended)
- 24GB+ RAM

### Installation
```bash
# Install Git LFS
# Linux
sudo apt-get install git-lfs
git lfs version
git lfs install

#How to commit through git-lfs
pl:
git lfs track "FinalCode/**"
git add .gitattributes FinalCode/
git commit -m "Add LFS tracking rules and files in the FinalCode directory"

# Clone the repository

git lfs clone https://github.com/RavenCaffeine/2025T3-COMP9517.git
cd 2025T3-COMP9517

# Create virtual environment
conda create -n comp9517 python=3.11

pip install ipykernel 

python -m ipykernel install --user --name comp9517 --display-name comp9517

conda activate comp9517
# Install dependencies
pip install -r requirements.txt
```

### Required Libraries
- OpenCV
- numpy
- pandas
- matplotlib
- scikit-learn
- albumentations (for data augmentation)
- ultralytics (for YOLO)
- pycocotools (for evaluation metrics)
- torch>=2.0.0
- torchvision>=0.15.0
- pyyaml
- seaborn>=0.12.0
## Usage


# Methods Implemented

## Deep Learning Approaches
### 1. **YOLO (You Only Look Once)**
   - End-to-end object detection
   - Real-time inference capability
   - Data augmentation experiments
     #### **Training Configuration Hyperparameters**
     ```bash
        task="detect",          # Task type: object detection (corresponds to command: task=detect)
        mode="train",           # Mode: training (corresponds to command: mode=train)
        data="/root/input/data.yaml",  # Path to dataset configuration file (corresponds to command: data=...)
        epochs=100,             # Number of training epochs (corresponds to command: epochs=100)
        patience=25,            # Early stopping patience (corresponds to command: patience=25)
        imgsz=256,             # Input image size (corresponds to command: imgsz=1024)
        batch=16,               # Batch size 
        lr0=0.01,               # Initial learning rate (corresponds to command: lr0=0.01)
        device=0,               # Device to use (0 for the first GPU, use device="cpu" for CPU; corresponds to command: device=0)
        name="yolo11n_experiment1",     # Subfolder for the current training run (corresponds to command: name=...)
        save=True,              # Whether to save training results (corresponds to command: save=True)
        save_period=100,          # Save model every N epochs (corresponds to command: save_period=5)
        optimizer="AdamW", 
        weight_decay= 0.0005
        ```
### 2. **Faster R-CNN**
   - Two-stage detector with Region Proposal Network
   - High accuracy for precise localization

**Components**

#### 1. Backbone: ResNet50 with Feature Pyramid Network (FPN)

- Multi-scale feature maps via FPN
- Pre-trained on ImageNet for transfer learning


#### 2.Region Proposal Network (RPN)
- Generates region proposals (potential object locations)
- Shares convolutional features with detection head
- Reduces computational cost compared to selective search
####  3.Detection Head
- ROI Align for precise feature extraction
- Classification branch: Predicts object class
-Regression branch: Refines bounding box coordinates


####  4.Two-Stage Detection Pipeline
 ```bash
   Input Image → Backbone (ResNet50-FPN) → RPN (proposals) 
              → ROI Align → Classification + Box Regression → Detections
```



#### **Training Configuration Hyperparameters**
```bash
HP = {
    # Model architecture
    'backbone': 'resnet50',
    'fpn': True,
    'pretrained': True,              # ImageNet pre-trained weights
    
    # Training parameters
    'num_classes': 12,               # 12 pest classes
    'epochs': 30,
    'batch_size': 4,                 # Per GPU
    'num_workers': 4,
    
    # Optimizer (SGD with momentum)
    'learning_rate': 0.02,
    'momentum': 0.9,
    'weight_decay': 0.0001,
    
    # Learning rate schedule
    'lr_scheduler': 'multistep',
    'lr_steps': [16, 22],            # Decay at these epochs
    'lr_gamma': 0.1,                 # Decay factor
    
    # Data augmentation
    'horizontal_flip': True,
    'vertical_flip': True,
    'color_jitter': True,
    
    # RPN parameters
    'rpn_pre_nms_top_n_train': 2000,
    'rpn_post_nms_top_n_train': 2000,
    'rpn_nms_thresh': 0.7,
    
    # Detection parameters
    'box_score_thresh': 0.05,
    'box_nms_thresh': 0.5,
    'box_detections_per_img': 100,
}
```

#### Evaluation Metrics
COCO-Style Metrics
The notebook computes standard COCO evaluation metrics:

##### AP (Average Precision)

- AP@[IoU=0.50:0.95]: Primary metric (averaged over IoU thresholds)
- AP@IoU=0.50: Detection at IoU threshold 0.5
- AP@IoU=0.75: Detection at strict IoU threshold


##### AP by Object Size
- AP_small: For objects with area < 32²
- AP_medium: For objects with 32² ≤ area < 96²
- AP_large: For objects with area ≥ 96²


##### AR (Average Recall)
- AR@1: Recall with 1 detection per image
- AR@10: Recall with 10 detections per image
- AR@100: Recall with 100 detections per image




### 3. **RetinaNet**
   - Single-stage detector with Focal Loss
   - Addresses class imbalance issues


#### **Training Configuration Hyperparameters**

```bash
CONFIG = {
    'num_classes': 12,
    'batch_size': 8,
    'epochs': 30,
    'image_size': 1024,          # High resolution for small objects
    
    # Optimizer (SGD with momentum)
    'lr': 0.001,
    'momentum': 0.9,
    'weight_decay': 0.0001,
    
    # Learning Rate Schedule
    'lr_scheduler': 'step',
    'lr_step_size': 10,
    'lr_gamma': 0.1,              # Decay factor
    'warmup_epochs': 3,
    'warmup_factor': 0.1,
    
    # Early Stopping
    'early_stopping': True,
    'patience': 3,                # Stop if no improvement for 3 epochs
}
```

**Results Structure**
```bash
retinanet_results/
├── checkpoints/
│   ├── best_model.pth              # Best model by mAP
│   ├── latest_model.pth            # Most recent checkpoint
│   └── epoch_XX.pth                # Intermediate checkpoints
├── metrics/
│   ├── training_history.json       # Loss and metrics per epoch
│   ├── confusion_matrix.png        # Ground truth vs predictions
│   └── per_class_performance.png   # Precision/Recall/F1 by class
└── visualizations/
    ├── predictions/                # Sample prediction images
    └── roc_curves/                 # Per-class ROC curves

```

## Machine Learning Approach
### **1. Feature Extraction**
Two complementary feature descriptors are implemented:

- SIFT (Scale-Invariant Feature Transform)

    Detects and describes local features

    Robust to scale and rotation variations

    Captures distinctive keypoints in pest images


- SURF (Speeded-Up Robust Features)

    Faster alternative to SIFT
    Good performance on textured surfaces
    Efficient for real-time applications

### **2. Feature Encoding**
Bag-of-Visual-Words (BoVW)
Clusters feature descriptors using MiniBatch K-Means
Creates visual vocabulary (codebook)
Represents each image as a histogram of visual word occurrences
Default: 100 clusters (configurable)

### **3. Classification Models**
Multiple classifiers are trained and compared:

- Support Vector Machine (SVM)

    Non-linear kernel for complex decision boundaries
Effective in high-dimensional feature spaces


- Random Forest

    Ensemble of decision trees
Robust to overfitting
Provides feature importance insights


- K-Nearest Neighbors (KNN)

    Instance-based learning
Simple baseline for comparison


- MLP

- XGBOOST


## Project Structure
```
FinalCode                                                                                                                  
├───YOLO_Final 
    ├───YOLO_Final_quickAUG.ipynb  #Augmentation ablation study
    ├───YOLO_Final_Train.ipynb     #Train BaseLine
    ├───YOLO_Final_trainModel_yolos.ipynb  #Train YOLOv11s
    ├───YOLO_Final_Visualizeipynb                                                                                
└───yolo_Results                                                                                                        
    ├───ablation_study                                                                                                  
    │   ├───exp1_baseline                                                                                               
    │   │   └───weights                                                                                                 
    │   ├───exp2_color_only                                                                                             
    │   │   └───weights                                                                                                 
    │   ├───exp3_geometric_only                                                                                         
    │   │   └───weights                                                                                                 
    │   ├───exp4_mosaic_only                                                                                            
    │   │   └───weights                                                                                                 
    │   ├───exp5_mixup_only                                                                                             
    │   │   └───weights                                                                                                 
    │   ├───exp6_copypaste_only                                                                                         
    │   │   └───weights                                                                                                 
    │   ├───exp7_full_augmentation                                                                                      
    │   │   └───weights                                                                                                 
    │   └───figures                                                                                                     
    ├───experiment                                                                                                      
    ├───runs                                                                                                            
    │   └───detect                                                                                                      
    │       ├───yolo11m_experiment1                                                                                     
    │       │   └───weights                                                                                             
    │       ├───yolo11n_experiment1                                                                                     
    │       │   └───weights                                                                                             
    │       └───yolo11s_experiment1                                                                                     
    │           └───weights                                                                                             
    ├───Test                                                                                                            
    ├───Train                                                                                                           
    ├───YOLO_MODEL  
├── MachineLearning.ipynb             #MachineLearning
├── FasterR-CNN+ResNet50-FPN.ipynb    #FasterRCNN
├── requirements.txt                  # Python dependencies
└── README.md
```



### 2. Training Models

**2.1 YOLO:**
```bash
jupyter notebook YOLO_Final/YOLO_Final_Train.ipynb
```
##### **2.1.1 Visualization and Analysis**
```bash
jupyter notebook YOLO_Final/YOLO_Final_Visualize.ipynb
```

##### **2.1.2 Augmentation ablation study**
```bash
jupyter notebook YOLO_Final/YOLO_Final_quickAUG.ipynb
```


**2.2 Faster R-CNN:**
```bash
jupyter notebook FasterR-CNN+ResNet50-FPN.ipynb
```

**2.3 RetinaNet:**
```bash
jupyter notebook RetinaNet.ipynb
```

**2.4 Machine Learning:**
```bash
jupyter notebook MachineLearning.ipynb
```

## Acknowledgments
- AgroPest-12 dataset by Rupankar Majumdar


# Troubleshooting
**Common Issues**
- CUDA Out of Memory
```bash
# Reduce batch size or image size
CONFIG['batch_size'] = 24
CONFIG['image_size'] = 256
```
